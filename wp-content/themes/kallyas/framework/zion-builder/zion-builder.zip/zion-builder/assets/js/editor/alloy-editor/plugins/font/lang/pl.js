/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'pl', {
	fontSize: {
		label: 'Rozmiar',
		voiceLabel: 'Rozmiar czcionki',
		panelTitle: 'Rozmiar'
	},
	label: 'Czcionka',
	panelTitle: 'Czcionka',
	voiceLabel: 'Czcionka'
} );
