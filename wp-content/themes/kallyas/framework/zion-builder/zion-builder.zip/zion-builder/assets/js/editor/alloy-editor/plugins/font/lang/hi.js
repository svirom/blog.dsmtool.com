/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'hi', {
	fontSize: {
		label: 'साइज़',
		voiceLabel: 'Font Size',
		panelTitle: 'साइज़'
	},
	label: 'फ़ॉन्ट',
	panelTitle: 'फ़ॉन्ट',
	voiceLabel: 'फ़ॉन्ट'
} );
